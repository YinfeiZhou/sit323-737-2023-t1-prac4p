const express = require('express');
const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.listen(PORT, () => {
    console.log(`Calculator microservice listening on port ${PORT}`);
});

const performOperation = (operation, num1, num2) => {
    if (typeof num1 !== 'number' || typeof num2 !== 'number') {
        throw new Error('Both "num1" and "num2" must be valid numbers.');
    }

    switch (operation) {
        case 'add':
            return num1 + num2;
        case 'subtract':
            return num1 - num2;
        case 'multiply':
            return num1 * num2;
        case 'divide':
            if (num2 === 0) {
                throw new Error('Division by zero is not allowed.');
            }
            return num1 / num2;
        default:
            throw new Error('Invalid operation.');
    }
};

app.post('/:operation', (req, res) => {
    const { operation } = req.params;
    const { num1, num2 } = req.body;

    try {
        const result = performOperation(operation, num1, num2);
        res.status(200).json({ result });
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
});
